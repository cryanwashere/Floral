# Floral
The best neural network library


Floral is a neural network library, created in Jax, by Cameron Ryan. In Flora, every tensor and operation is a graph node, and graphs are both inferenced and optimized through the same probe tracing algorithm. The benefit of Flora is that it's simple and efficient graph algorithm provides an easy interface with low level features. 
